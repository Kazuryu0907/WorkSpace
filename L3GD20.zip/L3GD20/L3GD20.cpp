#include <Wire.h>
#include "L3GD20.h"

L3GD20::L3GD20(int hex){
_ADDR = hex;
Wire.begin();
}

int L3GD20::L3GD20_read(int reg) {
  Wire.beginTransmission(_ADDR);
  Wire.write(reg);
  Wire.endTransmission();
  Wire.requestFrom(_ADDR, 1);
  return (Wire.read());
}

float L3GD20::getx(){
int l,h,x;
    l = L3GD20_read(L3GD20_OUT_X_L);
    h = L3GD20_read(L3GD20_OUT_X_H);
    x = (h << 8) | l;
float r;
r = x* 0.00875 * 0.01;
r = r/ 32.8 * 180;
return(r);
}

float L3GD20::gety(){
int l,h,y;
    l = L3GD20_read(L3GD20_OUT_Y_L);
    h = L3GD20_read(L3GD20_OUT_Y_H);
    y = (h << 8) | l;
float r;
r = y* 0.00875 * 0.01;
r = r/ 32.8 * 180;
return(r);
}

float L3GD20::getz(){
int l,h,z;
    l = L3GD20_read(L3GD20_OUT_Z_L);
    h = L3GD20_read(L3GD20_OUT_Z_H);
    z = (h << 8) | l;
float r;
r = z* 0.00875 * 0.01;
r = r/ 32.8 * 180;
return(r);
}

float L3GD20::getRadianx(){
int l,h,x;
    l = L3GD20_read(L3GD20_OUT_X_L);
    h = L3GD20_read(L3GD20_OUT_X_H);
    x = (h << 8) | l;
float r;
r = x* 0.00875 * 0.01;
r = r/ 32.8 * 3.14;
return(r);
}

float L3GD20::getRadiany(){
int l,h,y;
    l = L3GD20_read(L3GD20_OUT_Y_L);
    h = L3GD20_read(L3GD20_OUT_Y_H);
    y = (h << 8) | l;
float r;
r = y* 0.00875 * 0.01;
r = r/ 32.8 * 3.14;
return(r);
}

float L3GD20::getRadianz(){
int l,h,z;
    l = L3GD20_read(L3GD20_OUT_Z_L);
    h = L3GD20_read(L3GD20_OUT_Z_H);
    z = (h << 8) | l;
float r;
r = z* 0.00875 * 0.01;
r = r/ 32.8 * 3.14;
return(r);
}


