#ifndef L3GD20_KAZURYU
#define L3GD20_KAZURYU
#include <Wire.h>
class L3GD20{
    public:
        L3GD20(int hex);
        int L3GD20_read(int reg);
        float getx();
        float gety();
        float getz();
        float getRadianx();
        float getRadiany();
        float getRadianz();
    private:
        int _ADDR;
        const int L3GD20_WHOAMI = 0x0f;
        const int L3GD20_CTRL_REG1 = 0x20;
        const int L3GD20_OUT_X_L = 0x28;
        const int L3GD20_OUT_X_H = 0x29;
        const int L3GD20_OUT_Y_L = 0x2A;
        const int L3GD20_OUT_Y_H = 0x2B;
        const int L3GD20_OUT_Z_L = 0x2C;
        const int L3GD20_OUT_Z_H = 0x2D;

};

#endif