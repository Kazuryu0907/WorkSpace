#ifndef PID_LIBRARY
#define PID_LIBRARY
#include <Arduino.h>

class PID{
public:
    PID(uint8_t max,float Kp,float Ki,float Kd);
    float pid(float now);

private:
    uint8_t _max;
    float _Kp;
    float _Ki;
    float _Kd;
    float _f = 0;
    float _d = 0;
    float _hensa = 0;
};


#endif