#include <Arduino.h>
#include "PID.h"

PID::PID(uint8_t max,float Kp, float Ki, float Kd){
    _max = max;
    _Kp = Kp;
    _Ki = Ki;
    _Kd = Kd; 
}

float PID::pid(float nV){
  float sa = _max - nV;
  nV += _Kp*sa;
  _f += sa;
  nV += _f*_Ki;
  _d = _Kd*(sa-_hensa);
  nV += _d;
  _hensa = sa;
  return(nV);
}